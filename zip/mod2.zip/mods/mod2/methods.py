def hello():
    print("Hello from mod2!")