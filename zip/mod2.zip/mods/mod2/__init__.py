from classes import *
from objects import *
from methods import *
