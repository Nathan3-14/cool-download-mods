from methods import *
from blocks import *

values = ["methods", "blocks"]
