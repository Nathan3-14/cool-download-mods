from classes import Fruit

orange = Fruit("orange")