def hello():
    print("Hello from mod 1!")

